# Simple Chat Theme

It's a simple theme for a application chat, built with html5 css3 and Jquery,where you can switch between different theme

## Example

![alt text](img/screen.PNG "Description goes here")

## Example Dark theme

![alt text](img/screen-dark.PNG "Description goes here")

## Example Heat theme

![alt text](img/screen-hot.PNG "Description goes here")

## Installation

Just Donwload it and use

## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

## License
[MIT](https://choosealicense.com/licenses/mit/)
