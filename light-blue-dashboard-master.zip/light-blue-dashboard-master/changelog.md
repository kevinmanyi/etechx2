# Changelog
## [4.0.2]

### Updated and fixed

- Apdate several assets
- Fix charts
- Change main bg color
## [4.0.1]

### Updated and fixed

- Update main colors
- Fix tabs work
- Fix several charts
- Fix legend color in charts
- Several other fixes and improvements
