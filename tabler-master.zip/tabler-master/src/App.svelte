<main>

<div class="wrapper">
      <div class="content">
        <header class="topnav">
          <div class="container">
            <div class="navbar navbar-expand-lg navbar-light">
              <a href="." class="navbar-brand mr-4">
                <img src="./static/logo.svg" alt="Tabler" class="navbar-brand-logo navbar-brand-logo-lg">
                <img src="./static/logo-small.svg" alt="Tabler" class="navbar-brand-logo navbar-brand-logo-sm">
              </a>
              <ul class="nav navbar-menu align-items-center ml-auto">
                <li class="nav-item d-none d-lg-flex mr-3">
                  <a href="https://github.com/tabler/tabler" class="btn btn-secondary" target="_blank">
                    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" class="icon text-github" fill="currentColor">
                      <path d="M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12"/>
                    </svg>
                    Source code
                  </a>
                </li>
                <li class="nav-item dropdown">
                  <a href="#" data-toggle="dropdown"
			class="nav-link d-flex align-items-center py-0 px-lg-0 px-2 text-reset ml-2">
                    <span class="avatar avatar-sm" style="background-image: url(./static/avatars/004f.jpg)"></span>
                    <span class="ml-2 d-none d-lg-block lh-1">
                      Leesa Beaty
                      <span class="text-muted d-block mt-1 text-h6">Administrator</span>
                    </span>
                  </a>
                  <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                    <a class="dropdown-item" href="#">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon dropdown-icon"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                      Profile
                    </a>
                    <a class="dropdown-item" href="#">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon dropdown-icon"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg>
                      Settings
                    </a>
                    <a class="dropdown-item" href="#">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon dropdown-icon"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg>
                      Inbox
                      <span class="badge bg-primary ml-auto">6</span>
                    </a>
                    <a class="dropdown-item" href="#">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon dropdown-icon"><line x1="22" y1="2" x2="11" y2="13"></line><polygon points="22 2 15 22 11 13 2 9 22 2"></polygon></svg>
                      Message
                    </a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="#">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon dropdown-icon"><circle cx="12" cy="12" r="10"></circle><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"></path><line x1="12" y1="17" x2="12" y2="17"></line></svg>
                      Need help?
                    </a>
                    <a class="dropdown-item" href="#">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon dropdown-icon"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg>
                      Sign out
                    </a>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </header>
        <header class="topnav">
          <div class="navbar navbar-expand-lg navbar-light">
            <div class="container">
              <ul class="navbar-nav flex-wrap">
                <li class="nav-item active">
                  <a class="nav-link" href="./index.html" >
                    <span class="nav-icon">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>
                    </span>
                    Dashboard
                  </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="./form-elements.html" >
                    <span class="nav-icon">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon"><polyline points="9 11 12 14 22 4"></polyline><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path></svg>
                    </span>
                    Form elements
                  </a>
                </li>
                <li class="nav-item dropdown">
                  <a class="nav-link dropdown-toggle" href="#navbar-base" data-toggle="dropdown" role="button"
			aria-expanded="false" >
                    <span class="nav-icon">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon"><line x1="16.5" y1="9.4" x2="7.5" y2="4.21"></line><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path><polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline><line x1="12" y1="22.08" x2="12" y2="12"></line></svg>
                    </span>
                    Base
                  </a>
                  <ul class="dropdown-menu">
                    <li >
                      <a class="dropdown-item" href="./blank.html" >
                        Starter page
                      </a>
                    </li>
                    <li >
                      <a class="dropdown-item" href="./buttons.html" >
                        Buttons
                        <span class="badge bg-green ml-auto">New</span>
                      </a>
                    </li>
                    <li >
                      <a class="dropdown-item" href="./cards.html" >
                        Cards
                      </a>
                    </li>
                    <li >
                      <a class="dropdown-item" href="./datatables.html" >
                        Data Tables
                      </a>
                    </li>
                    <li >
                      <a class="dropdown-item" href="./calendar.html" >
                        Calendar
                      </a>
                    </li>
                    <li >
                      <a class="dropdown-item" href="./carousel.html" >
                        Carousel
                      </a>
                    </li>
                    <li >
                      <a class="dropdown-item" href="./users.html" >
                        Users
                      </a>
                    </li>
                    <li >
                      <a class="dropdown-item" href="./gallery.html" >
                        Gallery
                      </a>
                    </li>
                    <li >
                      <a class="dropdown-item" href="./profile.html" >
                        Profile
                      </a>
                    </li>
                    <li >
                      <a class="dropdown-item" href="./music.html" >
                        Music
                      </a>
                    </li>
                  </ul>
                </li>
				

				<!--
                <li class="nav-item">
                  <a class="nav-link" href="./charts.html" >
                    <span class="nav-icon">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon"><path d="M21.21 15.89A10 10 0 1 1 8 2.83"></path><path d="M22 12A10 10 0 0 0 12 2v10z"></path></svg>
                    </span>
                    Charts
                  </a>
                </li>
                <li class="nav-item dropdown">
                  <a class="nav-link dropdown-toggle" href="#navbar-error" data-toggle="dropdown" role="button"
			aria-expanded="false" >
                    <span class="nav-icon">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="9" y1="15" x2="15" y2="15"></line></svg>
                    </span>
                    Error pages
                  </a>
                  <ul class="dropdown-menu">
                    <li >
                      <a class="dropdown-item" href="./400.html" >
                        400 page
                      </a>
                    </li>
                    <li >
                      <a class="dropdown-item" href="./401.html" >
                        401 page
                      </a>
                    </li>
                    <li >
                      <a class="dropdown-item" href="./403.html" >
                        403 page
                      </a>
                    </li>
                    <li >
                      <a class="dropdown-item" href="./404.html" >
                        404 page
                      </a>
                    </li>
                    <li >
                      <a class="dropdown-item" href="./500.html" >
                        500 page
                      </a>
                    </li>
                    <li >
                      <a class="dropdown-item" href="./503.html" >
                        503 page
                      </a>
                    </li>
                    <li >
                      <a class="dropdown-item" href="./maintenance.html" >
                        Maintenance page
                      </a>
                    </li>
                  </ul>
                </li>
				-->

				<!--
                <li class="nav-item dropdown">
                  <a class="nav-link dropdown-toggle" href="#navbar-a" data-toggle="dropdown" role="button"
			aria-expanded="false" >
                    <span class="nav-icon">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon"><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line></svg>
                    </span>
                    A
                  </a>
                  <ul class="dropdown-menu">
                    <li class="dropright">
                      <a class="dropdown-item dropdown-toggle" href="#sidebar-b" data-toggle="dropdown" role="button" aria-expanded="false" >
                        B
                      </a>
                      <div class="dropdown-menu">
                        <a href="./tmp.html" class="dropdown-item">C</a>
                      </div>
                    </li>
                  </ul>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="./layouts.html" >
                    <span class="nav-icon">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><line x1="3" y1="9" x2="21" y2="9"></line><line x1="9" y1="21" x2="9" y2="9"></line></svg>
                    </span>
                    Layouts
                    <span class="badge bg-green ml-2">New</span>
                  </a>
                </li>
                <li class="nav-item dropdown">
                  <a class="nav-link dropdown-toggle" href="#navbar-extra" data-toggle="dropdown" role="button"
			aria-expanded="false" >
                    <span class="nav-icon">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>
                    </span>
                    Extra
                  </a>
                  <ul class="dropdown-menu">
                    <li >
                      <a class="dropdown-item" href="./invoice.html" >
                        Invoice
                      </a>
                    </li>
                    <li >
                      <a class="dropdown-item" href="./blog.html" >
                        Blog cards
                      </a>
                    </li>
                    <li >
                      <a class="dropdown-item" href="./search-results.html" >
                        Search results
                      </a>
                    </li>
                  </ul>
                </li>
                <li class="nav-item dropdown">
                  <a class="nav-link dropdown-toggle" href="#navbar-docs" data-toggle="dropdown" role="button"
			aria-expanded="false" >
                    <span class="nav-icon">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>
                    </span>
                    Documentation
                  </a>
                  <ul class="dropdown-menu">
                    <li >
                      <a class="dropdown-item" href="./docs/index.html" >
                        Introduction
                      </a>
                    </li>
                    <li >
                      <a class="dropdown-item" href="./docs/alerts.html" >
                        Alerts
                      </a>
                    </li>
                    <li >
                      <a class="dropdown-item" href="./docs/autosize.html" >
                        Autosize
                      </a>
                    </li>
                    <li >
                      <a class="dropdown-item" href="./docs/avatars.html" >
                        Avatars
                      </a>
                    </li>
                    <li >
                      <a class="dropdown-item" href="./docs/badges.html" >
                        Badges
                      </a>
                    </li>
                    <li >
                      <a class="dropdown-item" href="./docs/breadcrumb.html" >
                        Breadcrumb
                      </a>
                    </li>
                    <li >
                      <a class="dropdown-item" href="./docs/buttons.html" >
                        Buttons
                      </a>
                    </li>
                    <li >
                      <a class="dropdown-item" href="./docs/cards.html" >
                        Cards
                      </a>
                    </li>
                    <li >
                      <a class="dropdown-item" href="./docs/carousel.html" >
                        Carousel
                      </a>
                    </li>
                    <li >
                      <a class="dropdown-item" href="./docs/colors.html" >
                        Colors
                      </a>
                    </li>
                    <li >
                      <a class="dropdown-item" href="./docs/countup.html" >
                        Countup
                      </a>
                    </li>
                    <li >
                      <a class="dropdown-item" href="./docs/cursors.html" >
                        Cursors
                      </a>
                    </li>
                    <li >
                      <a class="dropdown-item" href="./docs/charts.html" >
                        Charts
                      </a>
                    </li>
                    <li >
                      <a class="dropdown-item" href="./docs/divider.html" >
                        Divider
                      </a>
                    </li>
                    <li >
                      <a class="dropdown-item" href="./docs/empty.html" >
                        Empty states
                      </a>
                    </li>
                    <li >
                      <a class="dropdown-item" href="./docs/flags.html" >
                        Flags
                      </a>
                    </li>
                    <li >
                      <a class="dropdown-item" href="./docs/form-elements.html" >
                        Form elements
                      </a>
                    </li>
                    <li >
                      <a class="dropdown-item" href="./docs/form-helpers.html" >
                        Form helpers
                      </a>
                    </li>
                    <li >
                      <a class="dropdown-item" href="./docs/input-mask.html" >
                        Form input mask
                      </a>
                    </li>
                    <li >
                      <a class="dropdown-item" href="./docs/layout.html" >
                        Layout
                      </a>
                    </li>
                    <li >
                      <a class="dropdown-item" href="./docs/progress.html" >
                        Progress
                      </a>
                    </li>
                    <li >
                      <a class="dropdown-item" href="./docs/payments.html" >
                        Payments
                      </a>
                    </li>
                    <li >
                      <a class="dropdown-item" href="./docs/ribbons.html" >
                        Ribbons
                        <span class="badge bg-green ml-auto">New</span>
                      </a>
                    </li>
                    <li >
                      <a class="dropdown-item" href="./docs/spinners.html" >
                        Spinners
                      </a>
                    </li>
                    <li >
                      <a class="dropdown-item" href="./docs/steps.html" >
                        Steps
                      </a>
                    </li>
                    <li >
                      <a class="dropdown-item" href="./docs/tables.html" >
                        Tables
                      </a>
                    </li>
                    <li >
                      <a class="dropdown-item" href="./docs/tabs.html" >
                        Tabs
                      </a>
                    </li>
                    <li >
                      <a class="dropdown-item" href="./docs/timelines.html" >
                        Timelines
                      </a>
                    </li>
                    <li >
                      <a class="dropdown-item" href="./docs/toasts.html" >
                        Toasts
                      </a>
                    </li>
                    <li >
                      <a class="dropdown-item" href="./docs/tooltips.html" >
                        Tooltips
                      </a>
                    </li>
                    <li >
                      <a class="dropdown-item" href="./docs/typography.html" >
                        Typography
                      </a>
                    </li>
                  </ul>
                </li>-->
              </ul> 
              <div class="navbar-search d-none d-xl-block">
                <form action="." method="get">
                  <div class="input-icon">
                    <span class="input-icon-addon">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
                    </span>
                    <input type="text" class="form-control" placeholder="Search&hellip;">
                  </div>
                </form>
              </div>
            </div>
          </div>
        </header>
        <div class="content-page">
          <main class="container my-4 flex-fill">
            <!-- Page title -->
            <div class="page-title-box">
              <div class="row align-items-center">
                <div class="col-auto">
                  <!-- Page pre-title -->
                  <div class="page-pretitle">
                    Overview
                  </div>
                  <h2 class="page-title">
                    Dashboard
                  </h2>
                </div>
                <!-- Page title actions -->
                <div class="col-auto ml-auto d-print-none">
                  <span class="d-none d-sm-inline">
                    <a href="#" class="btn btn-secondary">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
                      New view
                    </a>
                  </span>
                  <a href="#" class="btn btn-primary ml-3">
                    Create new report
                  </a>
                </div>
              </div>
            </div>
            <div class="row row-deck">
              <div class="col-sm-6 col-lg-3">
                <div class="card">
                  <div class="card-body">
                    <div class="d-flex">
                      <div>Sales</div>
                      <div class="ml-auto">
                        <div class="dropdown">
                          <a class="dropdown-toggle text-muted" href="#" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Last 7 days
                          </a>
                          <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuButton">
                            <a class="dropdown-item active" href="#">Last 7 days</a>
                            <a class="dropdown-item" href="#">Last 30 days</a>
                            <a class="dropdown-item" href="#">Last 3 months</a>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="h1 mb-3">75%</div>
                    <div class="d-flex mb-2">
                      <div>Conversion rate</div>
                      <div class="ml-auto">
                        <span class="text-green d-inline-flex align-items-center lh-1">
                          7% <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon ml-1"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"></polyline><polyline points="17 6 23 6 23 12"></polyline></svg>
                        </span>
                      </div>
                    </div>
                    <div class="progress progress-sm">
                      <div class="progress-bar bg-blue" style="width: 75%" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">
                        <span class="sr-only">75% Complete</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-sm-6 col-lg-3">
                <div class="card">
                  <div class="card-body">
                    <div class="d-flex">
                      <div>Revenue</div>
                      <div class="ml-auto">
                        <div class="dropdown">
                          <a class="dropdown-toggle text-muted" href="#" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Last 7 days
                          </a>
                          <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuButton">
                            <a class="dropdown-item active" href="#">Last 7 days</a>
                            <a class="dropdown-item" href="#">Last 30 days</a>
                            <a class="dropdown-item" href="#">Last 3 months</a>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="d-flex align-items-baseline">
                      <div class="h1 mb-0 mr-2">$4,300</div>
                      <div class="mr-auto">
                        <span class="text-green d-inline-flex align-items-center lh-1">
                          8% <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon ml-1"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"></polyline><polyline points="17 6 23 6 23 12"></polyline></svg>
                        </span>
                      </div>
                    </div>
                  </div>
                  <div id="chart-revenue-bg"  class="chart-sm" ></div>
                </div>
              </div>
              <div class="col-sm-6 col-lg-3">
                <div class="card">
                  <div class="card-body">
                    <div class="d-flex">
                      <div>New clients</div>
                      <div class="ml-auto">
                        <div class="dropdown">
                          <a class="dropdown-toggle text-muted" href="#" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Last 7 days
                          </a>
                          <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuButton">
                            <a class="dropdown-item active" href="#">Last 7 days</a>
                            <a class="dropdown-item" href="#">Last 30 days</a>
                            <a class="dropdown-item" href="#">Last 3 months</a>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="d-flex align-items-baseline">
                      <div class="h1 mb-3 mr-2">6,782</div>
                      <div class="mr-auto">
                        <span class="text-yellow d-inline-flex align-items-center lh-1">
                          0% <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon ml-1"><line x1="5" y1="12" x2="19" y2="12"></line></svg>
                        </span>
                      </div>
                    </div>
                    <div id="chart-new-clients"  class="chart-sm" ></div>
                  </div>
                </div>
              </div>
              <div class="col-sm-6 col-lg-3">
                <div class="card">
                  <div class="card-body">
                    <div class="d-flex">
                      <div>Active users</div>
                      <div class="ml-auto">
                        <div class="dropdown">
                          <a class="dropdown-toggle text-muted" href="#" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Last 7 days
                          </a>
                          <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuButton">
                            <a class="dropdown-item active" href="#">Last 7 days</a>
                            <a class="dropdown-item" href="#">Last 30 days</a>
                            <a class="dropdown-item" href="#">Last 3 months</a>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="d-flex align-items-baseline">
                      <div class="h1 mb-3 mr-2">2,986</div>
                      <div class="mr-auto">
                        <span class="text-green d-inline-flex align-items-center lh-1">
                          4% <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon ml-1"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"></polyline><polyline points="17 6 23 6 23 12"></polyline></svg>
                        </span>
                      </div>
                    </div>
                    <div id="chart-active-users"  class="chart-sm" ></div>
                  </div>
                </div>
              </div>
              <div class="col-lg-6">
                <div class="row">
                  <div class="col-md-6">
                    <div class="card">
                      <div class="card-body p-4 py-5 text-center">
                        <span class="avatar avatar-xl mb-4">W</span>
                        <h3 class="mb-0">New website</h3>
                        <p class="text-muted">Due to: 28 Aug 2019</p>
                        <p class="mb-3">
                          <span class="badge bg-red-lt">Waiting</span>
                        </p>
                        <div>
                          <div class="avatar-list avatar-list-stacked">
                            <span class="avatar" style="background-image: url(./static/avatars/000m.jpg)"></span>
                            <span class="avatar">JL</span>
                            <span class="avatar" style="background-image: url(./static/avatars/002m.jpg)"></span>
                            <span class="avatar" style="background-image: url(./static/avatars/003m.jpg)"></span>
                            <span class="avatar" style="background-image: url(./static/avatars/000f.jpg)"></span>
                          </div>
                        </div>
                      </div>
                      <div class="progress card-progress">
                        <div class="progress-bar" style="width: 38%" role="progressbar" aria-valuenow="38" aria-valuemin="0" aria-valuemax="100">
                          <span class="sr-only">38% Complete</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="card">
                      <div class="card-body p-4 py-5 text-center">
                        <span class="avatar avatar-xl mb-4 bg-green-lt">W</span>
                        <h3 class="mb-0">UI Redesign</h3>
                        <p class="text-muted">Due to: 11 Nov 2019</p>
                        <p class="mb-3">
                          <span class="badge bg-green-lt">Final review</span>
                        </p>
                        <div>
                          <div class="avatar-list avatar-list-stacked">
                            <span class="avatar">HS</span>
                            <span class="avatar" style="background-image: url(./static/avatars/006m.jpg)"></span>
                            <span class="avatar" style="background-image: url(./static/avatars/004f.jpg)"></span>
                          </div>
                        </div>
                      </div>
                      <div class="progress card-progress">
                        <div class="progress-bar bg-green" style="width: 38%" role="progressbar" aria-valuenow="38" aria-valuemin="0" aria-valuemax="100">
                          <span class="sr-only">38% Complete</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-6 col-sm-4">
                    <div class="card">
                      <div class="card-body p-2 text-center">
                        <div class="text-right text-green">
                          <span class="text-green d-inline-flex align-items-center lh-1">
                            6% <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon ml-1"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"></polyline><polyline points="17 6 23 6 23 12"></polyline></svg>
                          </span>
                        </div>
                        <div class="h1 m-0">43</div>
                        <div class="text-muted mb-4">New Tickets</div>
                      </div>
                    </div>
                  </div>
                  <div class="col-6 col-sm-4">
                    <div class="card">
                      <div class="card-body p-2 text-center">
                        <div class="text-right text-red">
                          <span class="text-red d-inline-flex align-items-center lh-1">
                            -2% <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon ml-1"><polyline points="23 18 13.5 8.5 8.5 13.5 1 6"></polyline><polyline points="17 18 23 18 23 12"></polyline></svg>
                          </span>
                        </div>
                        <div class="h1 m-0">95</div>
                        <div class="text-muted mb-4">Daily Earnings</div>
                      </div>
                    </div>
                  </div>
                  <div class="col-6 col-sm-4">
                    <div class="card">
                      <div class="card-body p-2 text-center">
                        <div class="text-right text-green">
                          <span class="text-green d-inline-flex align-items-center lh-1">
                            9% <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon ml-1"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"></polyline><polyline points="17 6 23 6 23 12"></polyline></svg>
                          </span>
                        </div>
                        <div class="h1 m-0">7</div>
                        <div class="text-muted mb-4">New Replies</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-lg-6">
                <div class="card">
                  <div class="card-header">
                    <h3 class="card-title">Top users</h3>
                  </div>
                  <div class="card-body">
                    <div id="map-world" style="height: 20rem"></div>
                  </div>
                </div>
              </div>
              <div class="col-lg-6">
                <div class="card">
                  <div id="chart-development-activity"  class="mt-4" ></div>
                  <div class="table-responsive">
                    <table class="table card-table table-vcenter">
                      <thead>
                        <tr>
                          <th colspan="2">User</th>
                          <th>Commit</th>
                          <th>Date</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td class="w-1p">
                            <span class="avatar">HS</span>
                          </td>
                          <td>Lorry Mion</td>
                          <td>Initial commit</td>
                          <td class="text-nowrap text-muted">May 6, 2019</td>
                        </tr>
                        <tr>
                          <td class="w-1p">
                            <span class="avatar" style="background-image: url(./static/avatars/005f.jpg)"></span>
                          </td>
                          <td>Avivah Mugleston</td>
                          <td>Main structure</td>
                          <td class="text-nowrap text-muted">April 22, 2019</td>
                        </tr>
                        <tr>
                          <td class="w-1p">
                            <span class="avatar" style="background-image: url(./static/avatars/010m.jpg)"></span>
                          </td>
                          <td>Dyann Escala</td>
                          <td>Left sidebar adjustments</td>
                          <td class="text-nowrap text-muted">April 15, 2019</td>
                        </tr>
                        <tr>
                          <td class="w-1p">
                            <span class="avatar" style="background-image: url(./static/avatars/004f.jpg)"></span>
                          </td>
                          <td>Perren Keemar</td>
                          <td>Topbar dropdown style</td>
                          <td class="text-nowrap text-muted">April 8, 2019</td>
                        </tr>
                        <tr>
                          <td class="w-1p">
                            <span class="avatar">AA</span>
                          </td>
                          <td>Tessie Curzon</td>
                          <td>Fixes #625</td>
                          <td class="text-nowrap text-muted">April 9, 2019</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
              <div class="col-lg-6">
                <div class="row row-deck">
                  <div class="col-md-12">
                  </div>
                  <div class="col-md-12">
                  </div>
                </div>
              </div>
              <div class="col-sm-6 col-xl-3">
                <div class="card">
                  <div class="card-body p-3 d-flex align-items-center">
                    <span class="bg-blue text-white stamp mr-3"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon"><line x1="12" y1="1" x2="12" y2="23"></line><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path></svg>
                    </span>
                    <div class="mr-3 lh-sm">
                      <div class="strong">
                        132 Sales
                      </div>
                      <div class="text-muted">12 waiting payments</div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-sm-6 col-xl-3">
                <div class="card">
                  <div class="card-body p-3 d-flex align-items-center">
                    <span class="bg-green text-white stamp mr-3"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon"><circle cx="9" cy="21" r="1"></circle><circle cx="20" cy="21" r="1"></circle><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path></svg>
                    </span>
                    <div class="mr-3 lh-sm">
                      <div class="strong">
                        78 Orders
                      </div>
                      <div class="text-muted">32 shipped</div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-sm-6 col-xl-3">
                <div class="card">
                  <div class="card-body p-3 d-flex align-items-center">
                    <div class="mr-3">
                      <div class="chart-sparkline" id="sparkline-12"></div>
                    </div>
                    <div class="mr-3 lh-sm">
                      <div class="strong">
                        1,352 Members
                      </div>
                      <div class="text-muted">163 registered today</div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-sm-6 col-xl-3">
                <div class="card">
                  <div class="card-body p-3 d-flex align-items-center">
                    <div class="mr-3 lh-sm">
                      <div class="strong">
                        132 Comments
                      </div>
                      <div class="text-muted">16 waiting</div>
                    </div>
                    <div class="ml-auto">
                      <div class="chart-sparkline chart-sparkline-square" id="sparkline-13"></div>
                    </div>
                  </div>
                </div>
              </div>
			<!--
              <div class="col-12">
                <div class="card">
                  <div class="card-header">
                    <h3 class="card-title">Invoices</h3>
                  </div>
                  <div class="card-body border-bottom py-3">
                    <div class="d-flex">
                      <div class="mb-0">
                        Show
                        <div class="mx-2 d-inline-block">
                          <input type="text" class="form-control form-control-sm" value="8" size="3">
                        </div>
                        entries
                      </div>
                      <div class="mb-0 ml-auto">
                        Search:
                        <div class="ml-2 d-inline-block">
                          <input type="text" class="form-control form-control-sm">
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="table-responsive">
                    <table class="table card-table table-vcenter text-nowrap datatable">
                      <thead>
                        <tr>
                          <th class="w-1p"><input class="form-check-input m-0 align-middle" type="checkbox"></th>
                          <th class="w-1p">No. <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-sm text-dark icon-thick"><polyline points="18 15 12 9 6 15"></polyline></svg>
                          </th>
                          <th>Invoice Subject <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-sm"><polyline points="16 18 22 12 16 6"></polyline><polyline points="8 6 2 12 8 18"></polyline></svg>
                          </th>
                          <th>Client <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-sm"><polyline points="16 18 22 12 16 6"></polyline><polyline points="8 6 2 12 8 18"></polyline></svg>
                          </th>
                          <th>VAT No. <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-sm"><polyline points="16 18 22 12 16 6"></polyline><polyline points="8 6 2 12 8 18"></polyline></svg>
                          </th>
                          <th>Created <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-sm"><polyline points="16 18 22 12 16 6"></polyline><polyline points="8 6 2 12 8 18"></polyline></svg>
                          </th>
                          <th>Status <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-sm"><polyline points="16 18 22 12 16 6"></polyline><polyline points="8 6 2 12 8 18"></polyline></svg>
                          </th>
                          <th>Price <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-sm"><polyline points="16 18 22 12 16 6"></polyline><polyline points="8 6 2 12 8 18"></polyline></svg>
                          </th>
                          <th></th>
                          <th></th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td><input class="form-check-input m-0 align-middle" type="checkbox"></td>
                          <td><span class="text-muted">001401</span></td>
                          <td><a href="invoice.html" class="text-reset" tabindex="-1">Design Works</a></td>
                          <td>
                            <span class="flag flag-country-us"></span>
                            Carlson Limited
                          </td>
                          <td>
                            87956621
                          </td>
                          <td>
                            15 Dec 2017
                          </td>
                          <td>
                            <span class="status-icon bg-success"></span> Paid
                          </td>
                          <td>$887</td>
                          <td class="text-right">
                            <button class="btn btn-secondary btn-sm align-text-top">Manage</button>
                            <span class="dropdown ml-1">
                              <button class="btn btn-secondary btn-sm dropdown-toggle align-text-top" data-toggle="dropdown">Actions</button>
                              <div class="dropdown-menu">
                                <a class="dropdown-item" href="#">
                                  Action
                                </a>
                                <a class="dropdown-item" href="#">
                                  Another action
                                </a>
                              </div>
                            </span>
                          </td>
                          <td>
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-sm float-right"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg>
                          </td>
                        </tr>
                        <tr>
                          <td><input class="form-check-input m-0 align-middle" type="checkbox"></td>
                          <td><span class="text-muted">001402</span></td>
                          <td><a href="invoice.html" class="text-reset" tabindex="-1">UX Wireframes</a></td>
                          <td>
                            <span class="flag flag-country-gb"></span>
                            Adobe
                          </td>
                          <td>
                            87956421
                          </td>
                          <td>
                            12 Apr 2017
                          </td>
                          <td>
                            <span class="status-icon bg-warning"></span> Pending
                          </td>
                          <td>$1200</td>
                          <td class="text-right">
                            <button class="btn btn-secondary btn-sm align-text-top">Manage</button>
                            <span class="dropdown ml-1">
                              <button class="btn btn-secondary btn-sm dropdown-toggle align-text-top" data-toggle="dropdown">Actions</button>
                              <div class="dropdown-menu">
                                <a class="dropdown-item" href="#">
                                  Action
                                </a>
                                <a class="dropdown-item" href="#">
                                  Another action
                                </a>
                              </div>
                            </span>
                          </td>
                          <td>
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-sm float-right"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg>
                          </td>
                        </tr>
                        <tr>
                          <td><input class="form-check-input m-0 align-middle" type="checkbox"></td>
                          <td><span class="text-muted">001403</span></td>
                          <td><a href="invoice.html" class="text-reset" tabindex="-1">New Dashboard</a></td>
                          <td>
                            <span class="flag flag-country-de"></span>
                            Bluewolf
                          </td>
                          <td>
                            87952621
                          </td>
                          <td>
                            23 Oct 2017
                          </td>
                          <td>
                            <span class="status-icon bg-warning"></span> Pending
                          </td>
                          <td>$534</td>
                          <td class="text-right">
                            <button class="btn btn-secondary btn-sm align-text-top">Manage</button>
                            <span class="dropdown ml-1">
                              <button class="btn btn-secondary btn-sm dropdown-toggle align-text-top" data-toggle="dropdown">Actions</button>
                              <div class="dropdown-menu">
                                <a class="dropdown-item" href="#">
                                  Action
                                </a>
                                <a class="dropdown-item" href="#">
                                  Another action
                                </a>
                              </div>
                            </span>
                          </td>
                          <td>
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-sm float-right"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg>
                          </td>
                        </tr>
                        <tr>
                          <td><input class="form-check-input m-0 align-middle" type="checkbox"></td>
                          <td><span class="text-muted">001404</span></td>
                          <td><a href="invoice.html" class="text-reset" tabindex="-1">Landing Page</a></td>
                          <td>
                            <span class="flag flag-country-br"></span>
                            Salesforce
                          </td>
                          <td>
                            87953421
                          </td>
                          <td>
                            2 Sep 2017
                          </td>
                          <td>
                            <span class="status-icon bg-secondary"></span> Due in 2 Weeks
                          </td>
                          <td>$1500</td>
                          <td class="text-right">
                            <button class="btn btn-secondary btn-sm align-text-top">Manage</button>
                            <span class="dropdown ml-1">
                              <button class="btn btn-secondary btn-sm dropdown-toggle align-text-top" data-toggle="dropdown">Actions</button>
                              <div class="dropdown-menu">
                                <a class="dropdown-item" href="#">
                                  Action
                                </a>
                                <a class="dropdown-item" href="#">
                                  Another action
                                </a>
                              </div>
                            </span>
                          </td>
                          <td>
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-sm float-right"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg>
                          </td>
                        </tr>
                        <tr>
                          <td><input class="form-check-input m-0 align-middle" type="checkbox"></td>
                          <td><span class="text-muted">001405</span></td>
                          <td><a href="invoice.html" class="text-reset" tabindex="-1">Marketing Templates</a></td>
                          <td>
                            <span class="flag flag-country-pl"></span>
                            Printic
                          </td>
                          <td>
                            87956621
                          </td>
                          <td>
                            29 Jan 2018
                          </td>
                          <td>
                            <span class="status-icon bg-danger"></span> Paid Today
                          </td>
                          <td>$648</td>
                          <td class="text-right">
                            <button class="btn btn-secondary btn-sm align-text-top">Manage</button>
                            <span class="dropdown ml-1">
                              <button class="btn btn-secondary btn-sm dropdown-toggle align-text-top" data-toggle="dropdown">Actions</button>
                              <div class="dropdown-menu">
                                <a class="dropdown-item" href="#">
                                  Action
                                </a>
                                <a class="dropdown-item" href="#">
                                  Another action
                                </a>
                              </div>
                            </span>
                          </td>
                          <td>
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-sm float-right"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg>
                          </td>
                        </tr>
                        <tr>
                          <td><input class="form-check-input m-0 align-middle" type="checkbox"></td>
                          <td><span class="text-muted">001406</span></td>
                          <td><a href="invoice.html" class="text-reset" tabindex="-1">Sales Presentation</a></td>
                          <td>
                            <span class="flag flag-country-br"></span>
                            Tabdaq
                          </td>
                          <td>
                            87956621
                          </td>
                          <td>
                            4 Feb 2018
                          </td>
                          <td>
                            <span class="status-icon bg-secondary"></span> Due in 3 Weeks
                          </td>
                          <td>$300</td>
                          <td class="text-right">
                            <button class="btn btn-secondary btn-sm align-text-top">Manage</button>
                            <span class="dropdown ml-1">
                              <button class="btn btn-secondary btn-sm dropdown-toggle align-text-top" data-toggle="dropdown">Actions</button>
                              <div class="dropdown-menu">
                                <a class="dropdown-item" href="#">
                                  Action
                                </a>
                                <a class="dropdown-item" href="#">
                                  Another action
                                </a>
                              </div>
                            </span>
                          </td>
                          <td>
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-sm float-right"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg>
                          </td>
                        </tr>
                        <tr>
                          <td><input class="form-check-input m-0 align-middle" type="checkbox"></td>
                          <td><span class="text-muted">001407</span></td>
                          <td><a href="invoice.html" class="text-reset" tabindex="-1">Logo & Print</a></td>
                          <td>
                            <span class="flag flag-country-us"></span>
                            Apple
                          </td>
                          <td>
                            87956621
                          </td>
                          <td>
                            22 Mar 2018
                          </td>
                          <td>
                            <span class="status-icon bg-success"></span> Paid Today
                          </td>
                          <td>$2500</td>
                          <td class="text-right">
                            <button class="btn btn-secondary btn-sm align-text-top">Manage</button>
                            <span class="dropdown ml-1">
                              <button class="btn btn-secondary btn-sm dropdown-toggle align-text-top" data-toggle="dropdown">Actions</button>
                              <div class="dropdown-menu">
                                <a class="dropdown-item" href="#">
                                  Action
                                </a>
                                <a class="dropdown-item" href="#">
                                  Another action
                                </a>
                              </div>
                            </span>
                          </td>
                          <td>
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-sm float-right"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg>
                          </td>
                        </tr>
                        <tr>
                          <td><input class="form-check-input m-0 align-middle" type="checkbox"></td>
                          <td><span class="text-muted">001408</span></td>
                          <td><a href="invoice.html" class="text-reset" tabindex="-1">Icons</a></td>
                          <td>
                            <span class="flag flag-country-pl"></span>
                            Tookapic
                          </td>
                          <td>
                            87956621
                          </td>
                          <td>
                            13 May 2018
                          </td>
                          <td>
                            <span class="status-icon bg-success"></span> Paid Today
                          </td>
                          <td>$940</td>
                          <td class="text-right">
                            <button class="btn btn-secondary btn-sm align-text-top">Manage</button>
                            <span class="dropdown ml-1">
                              <button class="btn btn-secondary btn-sm dropdown-toggle align-text-top" data-toggle="dropdown">Actions</button>
                              <div class="dropdown-menu">
                                <a class="dropdown-item" href="#">
                                  Action
                                </a>
                                <a class="dropdown-item" href="#">
                                  Another action
                                </a>
                              </div>
                            </span>
                          </td>
                          <td>
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-sm float-right"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                  <div class="card-footer d-flex align-items-center border-top-0">
                    <p class="m-0 text-muted">Showing <span>1</span> to <span>8</span> of <span>16</span> entries</p>
                    <ul class="pagination m-0 ml-auto">
                      <li class="page-item disabled">
                        <a class="page-link" href="#" tabindex="-1">
                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon"><polyline points="15 18 9 12 15 6"></polyline></svg>
                          Prev
                        </a>
                      </li>
                      <li class="page-item"><a class="page-link" href="#">1</a></li>
                      <li class="page-item active"><a class="page-link" href="#">2</a></li>
                      <li class="page-item"><a class="page-link" href="#">3</a></li>
                      <li class="page-item"><a class="page-link" href="#">4</a></li>
                      <li class="page-item"><a class="page-link" href="#">5</a></li>
                      <li class="page-item">
                        <a class="page-link" href="#">
                          Next <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon"><polyline points="9 18 15 12 9 6"></polyline></svg>
                        </a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              -->
			  <div class="col-12">
                <div class="card">
                  <div class="table-responsive">
                    <table class="table table-hover table-outline table-vcenter text-nowrap card-table">
                      <thead>
                        <tr>
                          <th colspan="2">User</th>
                          <th>Usage</th>
                          <th class="text-center">Payment</th>
                          <th>Activity</th>
                          <th class="text-center">Satisfaction</th>
                          <th class="text-center"><i class="icon-settings"></i></th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td class="text-center w-1p">
                            <span class="avatar" style="background-image: url(./static/avatars/023f.jpg)"></span>
                          </td>
                          <td>
                            <div>Eva Acres</div>
                            <div class="small text-muted">
                              Registered: Dec 14, 2019
                            </div>
                          </td>
                          <td>
                            <div class="clearfix">
                              <div class="float-left">
                                <strong>30%</strong>
                              </div>
                              <div class="float-right">
                                <small class="text-muted">Jun 11, 2015 - Jul 10, 2015</small>
                              </div>
                            </div>
                            <div class="progress progress-sm">
                              <div class="progress-bar bg-yellow" style="width: 30%" role="progressbar" aria-valuenow="30" aria-valuemin="0" aria-valuemax="100">
                                <span class="sr-only">30% Complete</span>
                              </div>
                            </div>
                          </td>
                          <td class="text-center">
                            <span class="payment payment-provider-visa"></span>
                          </td>
                          <td>
                            <div class="small text-muted">Last login</div>
                            <div>4 minutes ago</div>
                          </td>
                          <td class="text-center">
                            <!--					<div class="mx-auto" data-value="0.0"-->
                            <!--					     data-thickness="3" data-color="blue">-->
                            <!--						<div class="chart-circle-value">30%</div>-->
                            <!--					</div>-->
                            <div class="chart-sparkline chart-sparkline-square" id="sparkline-14"></div>
                          </td>
                          <td class="text-center">
                            <div class="dropdown">
                              <a class="btn-icon mx-2" data-toggle="dropdown">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon"><circle cx="12" cy="12" r="1"></circle><circle cx="12" cy="5" r="1"></circle><circle cx="12" cy="19" r="1"></circle></svg>
                              </a>
                              <div class="dropdown-menu">
                                <a class="dropdown-item" href="#">
                                  Action
                                </a>
                                <a class="dropdown-item" href="#">
                                  Another action
                                </a>
                              </div>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td class="text-center w-1p">
                            <span class="avatar" style="background-image: url(./static/avatars/027m.jpg)"></span>
                          </td>
                          <td>
                            <div>Jermaine Booley</div>
                            <div class="small text-muted">
                              Registered: Nov 27, 2019
                            </div>
                          </td>
                          <td>
                            <div class="clearfix">
                              <div class="float-left">
                                <strong>48%</strong>
                              </div>
                              <div class="float-right">
                                <small class="text-muted">Jun 11, 2015 - Jul 10, 2015</small>
                              </div>
                            </div>
                            <div class="progress progress-sm">
                              <div class="progress-bar bg-yellow" style="width: 48%" role="progressbar" aria-valuenow="48" aria-valuemin="0" aria-valuemax="100">
                                <span class="sr-only">48% Complete</span>
                              </div>
                            </div>
                          </td>
                          <td class="text-center">
                            <span class="payment payment-provider-googlewallet"></span>
                          </td>
                          <td>
                            <div class="small text-muted">Last login</div>
                            <div>6 minutes ago</div>
                          </td>
                          <td class="text-center">
                            <!--					<div class="mx-auto" data-value="0.0"-->
                            <!--					     data-thickness="3" data-color="blue">-->
                            <!--						<div class="chart-circle-value">48%</div>-->
                            <!--					</div>-->
                            <div class="chart-sparkline chart-sparkline-square" id="sparkline-15"></div>
                          </td>
                          <td class="text-center">
                            <div class="dropdown">
                              <a class="btn-icon mx-2" data-toggle="dropdown">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon"><circle cx="12" cy="12" r="1"></circle><circle cx="12" cy="5" r="1"></circle><circle cx="12" cy="19" r="1"></circle></svg>
                              </a>
                              <div class="dropdown-menu">
                                <a class="dropdown-item" href="#">
                                  Action
                                </a>
                                <a class="dropdown-item" href="#">
                                  Another action
                                </a>
                              </div>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td class="text-center w-1p">
                            <span class="avatar" style="background-image: url(./static/avatars/024f.jpg)"></span>
                          </td>
                          <td>
                            <div>Juanita Nobles</div>
                            <div class="small text-muted">
                              Registered: Jan 2, 2020
                            </div>
                          </td>
                          <td>
                            <div class="clearfix">
                              <div class="float-left">
                                <strong>9%</strong>
                              </div>
                              <div class="float-right">
                                <small class="text-muted">Jun 11, 2015 - Jul 10, 2015</small>
                              </div>
                            </div>
                            <div class="progress progress-sm">
                              <div class="progress-bar bg-red" style="width: 9%" role="progressbar" aria-valuenow="9" aria-valuemin="0" aria-valuemax="100">
                                <span class="sr-only">9% Complete</span>
                              </div>
                            </div>
                          </td>
                          <td class="text-center">
                            <span class="payment payment-provider-mastercard"></span>
                          </td>
                          <td>
                            <div class="small text-muted">Last login</div>
                            <div>a minute ago</div>
                          </td>
                          <td class="text-center">
                            <!--					<div class="mx-auto" data-value="0.0"-->
                            <!--					     data-thickness="3" data-color="blue">-->
                            <!--						<div class="chart-circle-value">9%</div>-->
                            <!--					</div>-->
                            <div class="chart-sparkline chart-sparkline-square" id="sparkline-16"></div>
                          </td>
                          <td class="text-center">
                            <div class="dropdown">
                              <a class="btn-icon mx-2" data-toggle="dropdown">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon"><circle cx="12" cy="12" r="1"></circle><circle cx="12" cy="5" r="1"></circle><circle cx="12" cy="19" r="1"></circle></svg>
                              </a>
                              <div class="dropdown-menu">
                                <a class="dropdown-item" href="#">
                                  Action
                                </a>
                                <a class="dropdown-item" href="#">
                                  Another action
                                </a>
                              </div>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td class="text-center w-1p">
                            <span class="avatar" style="background-image: url(./static/avatars/025f.jpg)"></span>
                          </td>
                          <td>
                            <div>Nanni Wooler</div>
                            <div class="small text-muted">
                              Registered: Oct 12, 2019
                            </div>
                          </td>
                          <td>
                            <div class="clearfix">
                              <div class="float-left">
                                <strong>98%</strong>
                              </div>
                              <div class="float-right">
                                <small class="text-muted">Jun 11, 2015 - Jul 10, 2015</small>
                              </div>
                            </div>
                            <div class="progress progress-sm">
                              <div class="progress-bar bg-green" style="width: 98%" role="progressbar" aria-valuenow="98" aria-valuemin="0" aria-valuemax="100">
                                <span class="sr-only">98% Complete</span>
                              </div>
                            </div>
                          </td>
                          <td class="text-center">
                            <span class="payment payment-provider-shopify"></span>
                          </td>
                          <td>
                            <div class="small text-muted">Last login</div>
                            <div>13 minutes ago</div>
                          </td>
                          <td class="text-center">
                            <!--					<div class="mx-auto" data-value="0.0"-->
                            <!--					     data-thickness="3" data-color="blue">-->
                            <!--						<div class="chart-circle-value">98%</div>-->
                            <!--					</div>-->
                            <div class="chart-sparkline chart-sparkline-square" id="sparkline-17"></div>
                          </td>
                          <td class="text-center">
                            <div class="dropdown">
                              <a class="btn-icon mx-2" data-toggle="dropdown">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon"><circle cx="12" cy="12" r="1"></circle><circle cx="12" cy="5" r="1"></circle><circle cx="12" cy="19" r="1"></circle></svg>
                              </a>
                              <div class="dropdown-menu">
                                <a class="dropdown-item" href="#">
                                  Action
                                </a>
                                <a class="dropdown-item" href="#">
                                  Another action
                                </a>
                              </div>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td class="text-center w-1p">
                            <span class="avatar" style="background-image: url(./static/avatars/026f.jpg)"></span>
                          </td>
                          <td>
                            <div>Mela Sydes</div>
                            <div class="small text-muted">
                              Registered: Nov 29, 2019
                            </div>
                          </td>
                          <td>
                            <div class="clearfix">
                              <div class="float-left">
                                <strong>46%</strong>
                              </div>
                              <div class="float-right">
                                <small class="text-muted">Jun 11, 2015 - Jul 10, 2015</small>
                              </div>
                            </div>
                            <div class="progress progress-sm">
                              <div class="progress-bar bg-yellow" style="width: 46%" role="progressbar" aria-valuenow="46" aria-valuemin="0" aria-valuemax="100">
                                <span class="sr-only">46% Complete</span>
                              </div>
                            </div>
                          </td>
                          <td class="text-center">
                            <span class="payment payment-provider-ebay"></span>
                          </td>
                          <td>
                            <div class="small text-muted">Last login</div>
                            <div>6 minutes ago</div>
                          </td>
                          <td class="text-center">
                            <!--					<div class="mx-auto" data-value="0.0"-->
                            <!--					     data-thickness="3" data-color="blue">-->
                            <!--						<div class="chart-circle-value">46%</div>-->
                            <!--					</div>-->
                            <div class="chart-sparkline chart-sparkline-square" id="sparkline-18"></div>
                          </td>
                          <td class="text-center">
                            <div class="dropdown">
                              <a class="btn-icon mx-2" data-toggle="dropdown">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon"><circle cx="12" cy="12" r="1"></circle><circle cx="12" cy="5" r="1"></circle><circle cx="12" cy="19" r="1"></circle></svg>
                              </a>
                              <div class="dropdown-menu">
                                <a class="dropdown-item" href="#">
                                  Action
                                </a>
                                <a class="dropdown-item" href="#">
                                  Another action
                                </a>
                              </div>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td class="text-center w-1p">
                            <span class="avatar" style="background-image: url(./static/avatars/028m.jpg)"></span>
                          </td>
                          <td>
                            <div>Price Letixier</div>
                            <div class="small text-muted">
                              Registered: Dec 15, 2019
                            </div>
                          </td>
                          <td>
                            <div class="clearfix">
                              <div class="float-left">
                                <strong>29%</strong>
                              </div>
                              <div class="float-right">
                                <small class="text-muted">Jun 11, 2015 - Jul 10, 2015</small>
                              </div>
                            </div>
                            <div class="progress progress-sm">
                              <div class="progress-bar bg-red" style="width: 29%" role="progressbar" aria-valuenow="29" aria-valuemin="0" aria-valuemax="100">
                                <span class="sr-only">29% Complete</span>
                              </div>
                            </div>
                          </td>
                          <td class="text-center">
                            <span class="payment payment-provider-paypal"></span>
                          </td>
                          <td>
                            <div class="small text-muted">Last login</div>
                            <div>3 minutes ago</div>
                          </td>
                          <td class="text-center">
                            <!--					<div class="mx-auto" data-value="0.0"-->
                            <!--					     data-thickness="3" data-color="blue">-->
                            <!--						<div class="chart-circle-value">29%</div>-->
                            <!--					</div>-->
                            <div class="chart-sparkline chart-sparkline-square" id="sparkline-19"></div>
                          </td>
                          <td class="text-center">
                            <div class="dropdown">
                              <a class="btn-icon mx-2" data-toggle="dropdown">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon"><circle cx="12" cy="12" r="1"></circle><circle cx="12" cy="5" r="1"></circle><circle cx="12" cy="19" r="1"></circle></svg>
                              </a>
                              <div class="dropdown-menu">
                                <a class="dropdown-item" href="#">
                                  Action
                                </a>
                                <a class="dropdown-item" href="#">
                                  Another action
                                </a>
                              </div>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td class="text-center w-1p">
                            <span class="avatar" style="background-image: url(./static/avatars/027f.jpg)"></span>
                          </td>
                          <td>
                            <div>Beatrix Ladewig</div>
                            <div class="small text-muted">
                              Registered: Nov 18, 2019
                            </div>
                          </td>
                          <td>
                            <div class="clearfix">
                              <div class="float-left">
                                <strong>57%</strong>
                              </div>
                              <div class="float-right">
                                <small class="text-muted">Jun 11, 2015 - Jul 10, 2015</small>
                              </div>
                            </div>
                            <div class="progress progress-sm">
                              <div class="progress-bar bg-yellow" style="width: 57%" role="progressbar" aria-valuenow="57" aria-valuemin="0" aria-valuemax="100">
                                <span class="sr-only">57% Complete</span>
                              </div>
                            </div>
                          </td>
                          <td class="text-center">
                            <span class="payment payment-provider-visa"></span>
                          </td>
                          <td>
                            <div class="small text-muted">Last login</div>
                            <div>7 minutes ago</div>
                          </td>
                          <td class="text-center">
                            <!--					<div class="mx-auto" data-value="0.0"-->
                            <!--					     data-thickness="3" data-color="blue">-->
                            <!--						<div class="chart-circle-value">57%</div>-->
                            <!--					</div>-->
                            <div class="chart-sparkline chart-sparkline-square" id="sparkline-20"></div>
                          </td>
                          <td class="text-center">
                            <div class="dropdown">
                              <a class="btn-icon mx-2" data-toggle="dropdown">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon"><circle cx="12" cy="12" r="1"></circle><circle cx="12" cy="5" r="1"></circle><circle cx="12" cy="19" r="1"></circle></svg>
                              </a>
                              <div class="dropdown-menu">
                                <a class="dropdown-item" href="#">
                                  Action
                                </a>
                                <a class="dropdown-item" href="#">
                                  Another action
                                </a>
                              </div>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td class="text-center w-1p">
                            <span class="avatar" style="background-image: url(./static/avatars/029m.jpg)"></span>
                          </td>
                          <td>
                            <div>Donnie Biggin</div>
                            <div class="small text-muted">
                              Registered: Oct 18, 2019
                            </div>
                          </td>
                          <td>
                            <div class="clearfix">
                              <div class="float-left">
                                <strong>91%</strong>
                              </div>
                              <div class="float-right">
                                <small class="text-muted">Jun 11, 2015 - Jul 10, 2015</small>
                              </div>
                            </div>
                            <div class="progress progress-sm">
                              <div class="progress-bar bg-green" style="width: 91%" role="progressbar" aria-valuenow="91" aria-valuemin="0" aria-valuemax="100">
                                <span class="sr-only">91% Complete</span>
                              </div>
                            </div>
                          </td>
                          <td class="text-center">
                            <span class="payment payment-provider-googlewallet"></span>
                          </td>
                          <td>
                            <div class="small text-muted">Last login</div>
                            <div>12 minutes ago</div>
                          </td>
                          <td class="text-center">
                            <!--					<div class="mx-auto" data-value="0.0"-->
                            <!--					     data-thickness="3" data-color="blue">-->
                            <!--						<div class="chart-circle-value">91%</div>-->
                            <!--					</div>-->
                            <div class="chart-sparkline chart-sparkline-square" id="sparkline-21"></div>
                          </td>
                          <td class="text-center">
                            <div class="dropdown">
                              <a class="btn-icon mx-2" data-toggle="dropdown">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon"><circle cx="12" cy="12" r="1"></circle><circle cx="12" cy="5" r="1"></circle><circle cx="12" cy="19" r="1"></circle></svg>
                              </a>
                              <div class="dropdown-menu">
                                <a class="dropdown-item" href="#">
                                  Action
                                </a>
                                <a class="dropdown-item" href="#">
                                  Another action
                                </a>
                              </div>
                            </div>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </main>
        </div>
      </div>
    </div>

</main>