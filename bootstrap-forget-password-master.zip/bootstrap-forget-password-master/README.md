# bootstrap-forget-password
Bootstrap Forget password template is a fully responsive template for Bootstrap lover's,  which include simple form and buttons - Created by Bootcatch team.

[![forget password](https://raw.githubusercontent.com/ajaymarathe/bootstrap-forget-password/master/img/forget-password.png)](https://ajaymarathe.github.io/bootstrap-forget-password/index.html)

## About

Bootcatch is an open source library of free Bootstrap templates and themes. All of the free templates and themes on Bootcatch are released under the MIT license, which means you can use them for any purpose, even for commercial projects.

* https://ajaymarathe.github.io/bootstrap-forget-password/index.html
* http://bootcatch.com

## Usage

After downloading, you can do whatever you want to do, like you can do changes in CSS and HTML files and make awesome templates as you want.
hope this will help you.

## Clone the Repository -

`git clone https://github.com/ajaymarathe/bootstrap-forget-password.git  `

## Author

Ajay Marathe

+ https://github.com/ajaymarathe
+ http://bootcatch.com

## Copyright and License

Copyright 2019 [Ajay Marathe](https://github.com/ajaymarathe). Code released under the [MIT](https://github.com/ajaymarathe/bootstrap-simple-blog/blob/master/LICENSE) license.

